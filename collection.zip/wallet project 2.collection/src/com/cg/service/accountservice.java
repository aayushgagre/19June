package com.cg.service;

import com.cg.DAO.AccountDAO;
import com.cg.DAO.AccountDAOImpl;
import com.cg.bean.*;
import com.cg.exception.*;
public class accountservice implements gst, transaction {

	
	
	AccountDAO dao=new AccountDAOImpl();
	
	public boolean addAccount(Account ob)
	{
		return dao.addAccount(ob);
	}
	
	public Account findAccount(Long mobileno)
	{
		return dao.findAccount(mobileno);
	}
	
	public boolean deleteAccount(Account ob)
	{
		return dao.deleteAccount(ob);
	}
	
	public boolean depositeMoney(Account ob, double money)
	{
		return dao.depositeMoney(ob,money);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public double withdraw(Account ob, double amount) throws InsufficientFundException {
		double new_balance=ob.getBalance()-amount;
		if(new_balance<100.00)
		{
			new_balance=ob.getBalance();
			
			//throw new RuntimeException("Insufficient Fund. Can not proceed further");
			throw new InsufficientFundException("Insufficient Fund. Can not proceed further",new_balance);
		}
		return new_balance;
	}

	@Override
	public double deposit(Account ob, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double transfermoney(Account from, Account to, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculatetax(double PCT, double amount) {
		// TODO Auto-generated method stub
		return amount*gst.PCT_5;
	}

}
