package com.cg.DAO;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Account;

public class AccountDAOImpl implements AccountDAO{

	static Map<Long, Account> accmap=new HashMap<Long, Account>();
	
	public boolean addAccount(Account ob)
	{
		accmap.put(ob.getMobile(), ob);
		return true;
	}

	@Override
	public boolean depositeMoney(Account ob, double money) {
		// TODO Auto-generated method stub
		double bal=ob.getBalance();
		double upd_bal=bal+money;
		
		ob.setBalance(upd_bal);
		
		return true;
	}

	@Override
	public boolean deleteAccount(Account ob) {
		// TODO Auto-generated method stub
		accmap.remove(ob.getMobile());
		return true;
	}

	@Override
	public Account findAccount(Long mobileno) {
		// TODO Auto-generated method stub
		Account ob=accmap.get(mobileno);
		return ob;
	}

	@Override
	public Map<Long, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean transferMoeny(Account from, Account to, double amount) {
		// TODO Auto-generated method stub
		return false;
	}
}
